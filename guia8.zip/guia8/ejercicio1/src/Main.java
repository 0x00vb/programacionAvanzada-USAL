public class Main {
    public static void main(String[] args){
        vista.Menu m = new vista.Menu(args);
        m.mostrarMenu();
    }
}

