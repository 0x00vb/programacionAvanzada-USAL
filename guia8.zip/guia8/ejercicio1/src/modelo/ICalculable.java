package modelo;

public interface ICalculable {
    public double calcularCostoTotal();
} 
