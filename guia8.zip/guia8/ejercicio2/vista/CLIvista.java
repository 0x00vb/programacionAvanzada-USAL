package vista;
public class CLIvista{
    public static void mostrarTexto(String a){
        System.out.println(a);
    }
}