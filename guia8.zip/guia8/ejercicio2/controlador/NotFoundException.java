package controlador;
public class NotFoundException extends Exception {
    public NotFoundException(String m){
        super(m);
    }
}
