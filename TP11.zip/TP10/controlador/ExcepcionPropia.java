package controlador;

public class ExcepcionPropia extends Exception {
    public ExcepcionPropia(String mensaje) {
        super(mensaje);
    }  
}
