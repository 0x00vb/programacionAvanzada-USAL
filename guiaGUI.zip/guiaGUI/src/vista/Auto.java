package vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Auto {
	public static void ingresoDatos() {
		
	}
}
