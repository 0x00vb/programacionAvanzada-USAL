import controlador.AutoControlador;
import vista.Menu;

public class Main {
	public static void main(String[] args) {
		AutoControlador autoControlador = new AutoControlador();
		Menu menu = new Menu();
	}
}
